from weathercom.weatherFunc import getCityWeatherDetails
# First get the city details from weather.com
# city = input("Enter the city name: ")
__version__ = '1.0.5'

